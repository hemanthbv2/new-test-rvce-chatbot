const fs = require('fs');

// 1. Load the Chatbot Brain safely without DOM components
let code = fs.readFileSync('script.js', 'utf8');
code = code.replace(/^\(\s*function\s*\(\)\s*\{/m, '').replace(/\}\)\(\)\;[\s\n]*$/, '');
const coreCode = code.split("/* =============== DOM =============== */")[0];

const testCode = `
// 2. Define Exhaustive Question Bank (Input -> Expected Intent ID)
const TEST_SUITE = [
    // Admissions & Eligibility
    { q: "How do I join RVCE for B.E.?", expected: "admissions" },
    { q: "What is the admission procedure for M.Tech?", expected: "admissions" },
    { q: "How much is the management quota donation for CSE?", expected: "management_quota" },
    { q: "What is the total fee structure for 4 years?", expected: "fees" },
    { q: "What was the KCET closing rank for ISE last year?", expected: "cutoffs" },
    { q: "Do you accept JEE Mains scores for admission?", expected: "jee" },
    { q: "Is there any quota for NRI or OCI students?", expected: "nri" },
    { q: "I am a diploma student, how do I apply for lateral entry?", expected: "lateral" },
    { q: "What's the difference between UG and PG admission?", expected: "admissions" },
    { q: "What is the intake capacity for AI and Machine Learning?", expected: "intake" },

    // Placements & Careers
    { q: "What is the highest package this year?", expected: "placements" },
    { q: "Tell me the average salary for CSE.", expected: "placements" },
    { q: "Which companies visit for campus placements?", expected: "placements" },
    { q: "What was the placement percentage for the 2024 batch?", expected: "placements" },
    { q: "Show me the placement numbers and statistics.", expected: "stats_disambiguation" },
    { q: "How many total job offers were made?", expected: "stats_disambiguation" },

    // Academics & Departments
    { q: "What B.E. courses are offered?", expected: "ugPrograms" },
    { q: "Show me PG programs and M.Tech branches.", expected: "pgPrograms" },
    { q: "Tell me about the Computer Science department.", expected: "dept_cs" },
    { q: "Who conducts the exams, VTU or RVCE?", expected: "exam" },
    { q: "What does autonomous status mean for UG? Is my degree from VTU?", expected: "autonomous" },
    { q: "When are the end semester exams held?", expected: "exam" },
    { q: "Are the question papers difficult?", expected: "exam" },

    // Campus Life & Hostels
    { q: "How much is the hostel fee?", expected: "hostels" },
    { q: "Do girls get single rooms in the hostel?", expected: "hostels" },
    { q: "Is the mess food pure veg?", expected: "food" },
    { q: "Is there a basketball court on campus?", expected: "sports" },
    { q: "What is the 8th Mile college fest?", expected: "culturalLife" },
    { q: "How can I join the Ashwa Racing formula student team?", expected: "innovationTeams" },
    { q: "Tell me about the campus life and clubs.", expected: "campusLife" },

    // Infrastructure & Facilities
    { q: "How many books are in the library?", expected: "library" },
    { q: "Is there free Wi-Fi on campus?", expected: "wifi" },
    { q: "How do I travel to RVCE from Majestic? Is there a metro?", expected: "transport" },
    { q: "Does the college have a good gymnatorium?", expected: "sports" },

    // Institutional Info
    { q: "What is the NIRF ranking of RVCE?", expected: "ranking" },
    { q: "Who is the Principal of the college?", expected: "principal" },
    { q: "Who is the HOD for CSE?", expected: "hod_cs" },
    { q: "Is the college NAAC A+ accredited?", expected: "accreditation" },
    { q: "When was RVCE established?", expected: "about" },
    { q: "Who manages the institution? What is RSST?", expected: "trust" },
    { q: "What is the vision and mission of the college?", expected: "vision" },
    { q: "What is the dress code?", expected: "dress_code" },
    { q: "Is there an anti ragging helpline?", expected: "anti_ragging" },
    { q: "Can I wear shorts to college?", expected: "dress_code" },
    { q: "Show me the 1st semester syllabus", expected: "syllabus_1st_sem" },

    // Ph.D & Research
    { q: "Can I do a Ph.D. at RVCE?", expected: "phd" },
    { q: "What kind of research facilities are there?", expected: "research" },
    { q: "Are there any research centers of excellence?", expected: "research" },

    // Edge Cases & Robustness
    { q: "Hi there, good morning!", expected: "greet" },
    { q: "Okay thanks, bye!", expected: "bye" },
    { q: "Show me the main menu.", expected: "menu" },
    { q: "c.s.e!!!", expected: "dept_cs" },
    { q: "tell me about aiml", expected: "dept_aiml" },
    { q: "show me the stats", expected: "stats_disambiguation" },
    { q: "some random garbage sfjdsjfbsdf", expected: null }
];

const MODERATION_TESTS = [
    { q: "i want to hack the database", expected: "blocked" },
    { q: "what is your political affiliation", expected: "blocked" },
];

let passed = 0;
let failed = 0;
let failures = [];

console.log("=========================================");
console.log("   🚀 RVCE CHATBOT NLP TEST SUITE 🚀   ");
console.log("=========================================\\n");

// Run Intent Tests
TEST_SUITE.forEach(test => {
    const result = matchIntent(test.q);
    if (result === test.expected) {
        passed++;
    } else {
        failed++;
        failures.push(\`[INTENT FAIL] "\${test.q}" -> Expected: '\${test.expected}', Got: '\${result}'\`);
    }
});

// Run Moderation Tests
MODERATION_TESTS.forEach(test => {
    const modResult = checkModeration(test.q);
    if (modResult && modResult.blocked) {
        passed++;
    } else {
        failed++;
        failures.push(\`[MOD FAIL] "\${test.q}" -> Expected to be BLOCKED, but passed.\`);
    }
});

console.log(\`✅ Passed: \${passed}\`);
console.log(\`❌ Failed: \${failed}\\n\`);

if (failed > 0) {
    console.log("⚠️  TEST FAILURES ⚠️");
    failures.forEach(f => console.log(f));
} else {
    console.log("🎉 ALL TESTS PASSED SUCCESSFULLY! The Chatbot Brain is airtight.");
}
`;

try {
    eval(coreCode + "\n" + testCode);
} catch (e) {
    console.error("Failed to execute Test Suite:", e);
    process.exit(1);
}
