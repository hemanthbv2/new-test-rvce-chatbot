/* RVCE Chatbot v3 — Smart Engine with Content Moderation */
(function () {
'use strict';

let tone = 'funny';
let chatOpen = false;

/* =============== CONTENT MODERATION =============== */
const BLOCKED = {
    abusive: [
        'fuck','shit','ass','bitch','bastard','damn','dick','pussy','slut','whore',
        'stupid','idiot','dumb','moron','retard','crap','screw you','shut up','suck',
        'hate you','loser','trash','worthless','ugly','go to hell','kill','murder',
        'rape','abuse','harass','molest','stalk','threat','bomb','attack','terror',
        'drug','weed','cocaine','heroin','alcohol','drunk','smoke','gambling','porn',
        'sex','nude','naked','obscene','vulgar','profanity','racist','sexist','bigot',
        'ass hole','wtf','stfu','lmao','lmfao','bloody','madarchod','behenchod',
        'chutiya','bc','mc','gaand','saala','kamina','haramkhor','bewakoof','gadha','hack'
    ],
    conspiracy: [
        'illuminati','flat earth','reptilian','chemtrail','5g cause','qanon','deep state',
        'new world order','fake moon','area 51','aliens control','government mind control',
        'covid fake','vaccine microchip','bill gates chip','controlled demolition',
        'pizza gate','fake news media','rigged election','brainwash','propaganda',
        'freemason','secret society','population control','depopulation','mk ultra','political affiliation'
    ],
    private: [
        'student phone number','personal number','private email','home address',
        'student address','teacher address','salary of','faculty salary',
        'personal data','student marks','result of','cgpa of','gpa of',
        'marks of','percentage of','private detail','confidential','password',
        'bank detail','account number','aadhaar','pan card','dob of','date of birth of',
        'caste of','religion of','family of','father of','mother of','girlfriend',
        'boyfriend','relationship','married','wife of','husband of','someone\'s phone',
        'whatsapp number','instagram id','social media of','facebook of'
    ]
};

const SESSION = {
    lastIntent: null,
    history: []
};

const PREFIXES = [
    "Sure thing!", "I can help with that!", "Got it!", "Great question.",
    "Here's what I found:", "Looking into that...", "Certainly!", "Happy to help."
];

function getPrefix() {
    return PREFIXES[Math.floor(Math.random() * PREFIXES.length)] + " ";
}

function checkModeration(input) {
    const lower = input.toLowerCase();
    
    // Helper to check for blocked pattern with word boundaries
    const isBlocked = (list) => {
        for (const word of list) {
            // Escape special chars and use word boundary (?:^|\s) and (?=\s|$) for broad match
            // or use \b if we want strict letter boundaries. 
            // Given "c.s.e" type sanitization, \b is generally safe for letters/numbers.
            const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regex = new RegExp('(?:^|\\s)' + escaped + '(?=\\s|$|[?!.])', 'i');
            if (regex.test(lower)) return true;
        }
        return false;
    };

    if (isBlocked(BLOCKED.abusive)) return { blocked: true, type: 'abusive' };
    if (isBlocked(BLOCKED.conspiracy)) return { blocked: true, type: 'conspiracy' };
    if (isBlocked(BLOCKED.private)) return { blocked: true, type: 'private' };
    
    return { blocked: false };
}

function getModerationResponse(type) {
    const responses = {
        abusive: {
            funny: "Whoa there! 🚫 Let's keep it friendly, shall we? I'm here to help with RVCE stuff, not to trade insults! 😅",
            pro: "⚠️ I'm unable to respond to inappropriate or offensive language. Please keep our conversation respectful. I'm here to help you with genuine RVCE queries."
        },
        conspiracy: {
            funny: "Nice try! 🛸 But I only deal in verified RVCE facts, not conspiracy theories! Let's stick to something I can actually help with 😄",
            pro: "⚠️ I'm designed to provide factual information about RVCE only. I cannot engage with conspiracy theories or unverified claims. Please ask me about admissions, placements, or campus facilities."
        },
        private: {
            funny: "Sorry, that's classified! 🔒 I can't share anyone's private information. I'm a college chatbot, not a spy! 🕵️",
            pro: "⚠️ I cannot share personal or confidential information about students, faculty, or staff. This includes contact details, marks, or personal data. I can help with general college information instead."
        }
    };
    return responses[type][tone === 'funny' ? 'funny' : 'pro'];
}

/* =============== KNOWLEDGE BASE =============== */
const KB = {
    general: {
        name: "RV College of Engineering (RVCE)", est: "1963",
        campus: "16.85 acres on Mysuru Road, Bengaluru – 560 059",
        trust: "Rashtreeya Sikshana Samithi Trust (RSST)",
        status: "Autonomous (UG), Affiliated to VTU",
        accreditation: "NAAC A+ Grade, NBA Accredited",
        ranking: "NIRF 101-150 band (Engineering, 2025), #1 Private Engineering College in IIRF 2025",
        principal: "Dr. K.N. Subramanya",
        timings: "Mon-Fri: 9:00 AM – 4:45 PM, Sat: 9:00 AM – 1:00 PM",
        vision: "Leadership in quality technical education, interdisciplinary research & innovation, with focus on sustainable and inclusive technology.",
        intake: "2000+ students annually across UG and PG",
        research: "100+ Patents, ₹30+ Crores in grants, 20 Centres of Excellence, 15 VTU-recognized Research Centres",
        researchDomains: "AI, Quantum Tech, 5G, Electric Vehicles, Hydrogen Technology, IC Design"
    },
    contact: {
        address: "RV College of Engineering, RV Vidyanikethan Post, Mysuru Road, Bengaluru – 560 059",
        phone: "+91-080-68188112 / 8111", admissionPhone: "080-68188147/48/49",
        email: "principal@rvce.edu.in", placementPhone: "9886130504",
        website: "https://rvce.edu.in/"
    },
    placements: {
        companies: "249 companies participated in the 2024 campus drive", avgSalary: "~₹35 LPA (2024 Avg)",
        maxSalary: "₹92 LPA Highest Package (2024 Batch)", recruiters: "ABB, Boeing, CTS, Infosys, Wipro, TCS, Amazon, Microsoft",
        scholarships: "₹72+ Lakhs awarded to ~110 students annually from ABB, Boeing, CTS",
        infra: "800+ systems, seminar halls, 6 interview rooms, 2 GD rooms",
        offers: "917 total offers with a 75% placement rate for 2024",
        url: "https://rvce.edu.in/placement_and_training/"
    },
    admissions: {
        ug: { eligibility: "12th/2nd PUC with min 45% in Physics + Maths + Chemistry/Biotech/Biology/CS/Electronics (40% for SC/ST/OBC Karnataka)", exams: "KCET (KEA), COMED-K, Management Quota. JEE Mains is NOT considered.", quotas: "Also available: CIWG/PIO/OCI/Nepal Citizens quota" },
        pg: { eligibility: "B.E./B.Tech with min 50% marks (45% for SC/ST/OBC Karnataka)", exams: "Valid GATE or PGCET score" },
        mca: { eligibility: "Bachelor's degree with min 50% marks (45% for SC/ST/OBC Karnataka)" },
        phd: { info: "Doctoral programs in all departments via entrance test + interview. 15 VTU-recognized Research Centres." },
        fees: "Management Quota B.E. fees range from ~₹16 Lakhs to ~₹70 Lakhs total over 4 years (e.g., CSE highest at ~₹70L, Core branches ~₹16L-₹24L). M.Tech/MCA ranges from ₹2L to ₹16L.",
        cutoffs: "Official KCET cutoffs are released by KEA (e.g., ISE cutoff was ~832 in 2023).",
        url: "https://rvce.edu.in/admissions/"
    },
    departments: {
        ug: [
            {n:"Aerospace Engineering (AE)",c:"ae"},{n:"AI & Machine Learning (AIML)",c:"aiml"},
            {n:"Biotechnology (BT)",c:"bt"},{n:"Chemical Engineering (CH)",c:"ch"},
            {n:"Civil Engineering (CV)",c:"cv"},{n:"Computer Science & Engg (CSE)",c:"cs"},
            {n:"CSE (AI & ML) (CSAIML)",c:"csaiml"},{n:"CSE (Cyber Security) (CSCY)",c:"cscy"},
            {n:"CSE (Data Science) (CSDS)",c:"csds"},{n:"Electrical & Electronics (EEE)",c:"ee"},
            {n:"Electronics & Communication (ECE)",c:"ec"},{n:"Electronics & Instrumentation (EIE)",c:"ei"},
            {n:"Electronics & Telecom (ETE)",c:"et"},{n:"Industrial Engg & Mgmt (IEM)",c:"im"},
            {n:"Information Science & Engg (ISE)",c:"is"},{n:"Mechanical Engineering (ME)",c:"me"}
        ],
        pg: [
            {n:"M.Tech Biotechnology",c:"bt"},{n:"M.Tech Structural Engg",c:"cv"},
            {n:"M.Tech Highway Tech",c:"cv"},{n:"M.Tech CSE",c:"cs"},
            {n:"M.Tech Computer Network Engg",c:"cs"},{n:"M.Tech Power Electronics",c:"ee"},
            {n:"M.Tech VLSI & Embedded",c:"ec"},{n:"M.Tech Comm Systems",c:"ec"},
            {n:"M.Tech Software Engg",c:"is"},{n:"M.Tech Info Tech",c:"is"},
            {n:"M.Tech Product Design",c:"me"},{n:"M.Tech Machine Design",c:"me"},
            {n:"M.Tech Digital Comm",c:"et"},{n:"MCA",c:"mca"}
        ]
    },
    hostels: {
        boys: "Chamundi, Cauvery, Sir MV, Krishna blocks",
        girls: "Diamond Jubilee, Krishna Garden blocks",
        amenities: "Vegetarian mess, Wi-Fi, laundry, 24/7 security",
        note: "Allotted during admission — no advance booking",
        url: "https://rvce.edu.in/facilities/"
    },
    facilities: {
        list: ["Central Library","Food Court","Sports Complex (400m track, Cricket/Football)","Health Centre","ICICI Bank","Post Office","Gymnatorium","Labs & Workshops"],
        url: "https://rvce.edu.in/facilities/"
    },
    campus: {
        teams: ["Team Ashwa (Formula Student)","Team Chimera (Hybrid Vehicle)","Project Jatayu (UAV)","ASTRA Robotics","Team Antariksh (Satellite)"],
        clubs: ["Alaap (Music)","Footprints (Dance)","CARV (Theatre)","TEDxRVCE","Rotaract Club"],
        fest: "8th Mile — Annual College Fest",
        urls: { innovation:"https://rvce.edu.in/innovative_teams/", cultural:"https://rvce.edu.in/cultural_teams/" }
    }
};

function dUrl(c) { return `https://rvce.edu.in/department/${c}/main-department/`; }

/* =============== INPUT SANITIZATION =============== */
function sanitize(input) {
    // 1. Remove dots explicitly to handle c.s.e -> cse
    let cleaned = input.replace(/\./g, '');
    // 2. Remove other special chars
    cleaned = cleaned.replace(/[^a-zA-Z0-9\s]/g, ' ');
    // 3. Remove extra spaces
    return cleaned.replace(/\s+/g, ' ').trim();
}

/* =============== INTENT MATCHING (Priority-based) =============== */
// p: 0=greet/bye, 1=very specific, 2=medium, 3=generic fallback
const QA = [
    {k:['hi','hello','hey','hii','hola','good morning','good evening','good afternoon','Namaste','yo','sup','howdy','wassup'],id:'greet',p:0},
    {k:['bye','goodbye','thank you','thanks','thats all','see you','cya','take care','ok bye','okay bye','good night','tata'],id:'bye',p:0},
    // P1: Specific topics
    {k:['hostel','hostels','accommodation','dorm','dormitory','boys hostel','girls hostel','hostel fee','hostel room','single room','shared room','hostel mess','staying','where to stay','stay at rvce'],id:'hostels',p:1},
    {k:['transport','how to reach','bmtc','bus route','kengeri metro','commute to rvce','distance from','reach rvce','reach the college','how to get there','travel to rvce'],id:'transport',p:1},
    {k:['wifi','internet','wi fi','connectivity','broadband','net access'],id:'wifi',p:1},
    {k:['canteen','food','mess food','eat','dining','cafeteria','food court','what to eat','lunch','breakfast','snacks'],id:'food',p:1},
    {k:['exam','exams','examination','examinations','semester exam','end semester','internal','assessment','cie','end sem','mid sem','exam pattern','question paper','question papers'],id:'exam',p:1},
    {k:['lateral','lateral entry','diploma holder','dcet'],id:'lateral',p:1},
    {k:['nri','international student','foreign student','overseas','ciwg','pio','oci'],id:'nri',p:1},
    {k:['scholarship','financial aid','stipend','merit scholarship'],id:'scholarships',p:1},
    {k:['jee','jee mains','jee main','jee accepted','jee score'],id:'jee',p:1},
    {k:['kcet','comedk','comed k'],id:'examTypes',p:1},
    {k:['management quota','management seat','direct admission','donation seat'],id:'management_quota',p:1},
    {k:['cutoff','cut off','closing rank','kcet rank','comedk cutoff'],id:'cutoffs',p:1},
    {k:['fee','fees','tuition','fee structure','semester fee','total cost','how much cost','how much does it cost'],id:'fees',p:1},
    {k:['refund','fee refund','cancellation','cancel admission','get money back','refund policy','aicte refund'],id:'refund_policy',p:1},
    {k:['syllabus','1st semester syllabus','1st sem syllabus','first semester syllabus','scheme','first year subjects','1st year syllabus','what are we studying'],id:'syllabus_1st_sem',p:0.8},
    {k:['innovation team','formula student','uav','ashwa','chimera','jatayu','astra robotics','antariksh','student projects','project teams'],id:'innovationTeams',p:1},
    {k:['cultural life','culture','cultural life','college culture','music club','dance club','theatre','drama','tedx','tedxrvce','rotaract','fest','8th mile','eighth mile','annual fest','college fest','events','college events','cultural events','cultural activities'],id:'culturalLife',p:1},
    {k:['vision','mission','motto'],id:'vision',p:1},
    {k:['principal','principal name','who is principal','head of institution','director of rvce','who is the principal','about principal','tell me about principal'],id:'principal',p:1},
    {k:['hod cs','hod cse','head of department cs','head of department cse','cs hod','cse hod','who is the hod of cse','hod for cse','hod of cse'],id:'hod_cs',p:0.5},
    {k:['ranking','nirf','iirf','college ranking','where does rvce rank','ranked','best college'],id:'ranking',p:1},
    {k:['accreditation','naac','nba','naac grade'],id:'accreditation',p:1},
    {k:['timing','timings','working hours','college hours','college time','what time','opening time','closing time','open close'],id:'timings',p:1},
    {k:['trust','rsst','rvei','parent organization','who manages'],id:'trust',p:1},
    {k:['research','patent','patents','innovation centre','centre of excellence','research centre','grants','funding','research at rvce'],id:'research',p:1},
    {k:['mca','master of computer application','mca dept','mca department'],id:'mca',p:1},
    {k:['phd','doctoral','doctorate','research program','doctor degree'],id:'phd',p:1},
    {k:['vtu','visvesvaraya','affiliated university','university affiliation'],id:'vtu',p:1},
    {k:['seat','seats','total seats','intake','how many students','total students','student count','student strength','intake capacity'],id:'intake',p:0.5},
    {k:['library','central library','books','reading room','e library','digital library'],id:'library',p:0.3},
    {k:['sports','cricket','football','basketball','volleyball','athletics','gym','gymnatorium','sports complex','games'],id:'sports',p:1},
    {k:['autonomous','autonomy','own syllabus','own exam'],id:'autonomous',p:1},
    {k:['stat','stats','statistic','statistics','number','numbers','figure','figures','data','how many'],id:'stats_disambiguation',p:0.4},
    // Department-specific (with short codes)
    {k:['computer science','cse','cs department','computer science engineering','cse department'],id:'dept_cs',p:1},
    {k:['artificial intelligence','aiml','ai ml','machine learning','ai department','ai branch'],id:'dept_aiml',p:1},
    {k:['electronics and communication','ece','ec department','ece department'],id:'dept_ec',p:1},
    {k:['mechanical engineering','me department','mech','mech department','mechanical'],id:'dept_me',p:1},
    {k:['civil engineering','cv department','civil department','civil'],id:'dept_cv',p:1},
    {k:['electrical','eee','ee department','eee department','electrical engineering'],id:'dept_ee',p:1},
    {k:['aerospace','ae department','aero','aero department','aeronautical','aerospace engineering'],id:'dept_ae',p:1},
    {k:['biotech','bt','biotechnology','bio technology','bt department'],id:'dept_bt',p:1},
    {k:['chemical engineering','ch department','chemical engg','che'],id:'dept_ch',p:1},
    {k:['information science','ise','is department','ise department'],id:'dept_is',p:1},
    {k:['data science','csds','cs data science','csds department'],id:'dept_csds',p:1},
    {k:['cyber security','cscy','cs cyber security','cscy department'],id:'dept_cscy',p:1},
    {k:['telecom','ete','telecommunication','ete department'],id:'dept_et',p:1},
    {k:['instrumentation','eie','ei department','eie department'],id:'dept_ei',p:1},
    {k:['industrial engineering','iem','iem department','industrial management'],id:'dept_im',p:1},
    // P2: Mid-level
    {k:['placement','placements','placed','salary','package','lpa','ctc','highest package','average salary','recruit','hiring','companies visit','which companies','recruiters','job','jobs','placement details'],id:'placements',p:0.5},
    {k:['admission','admissions','how to apply','how to join','entrance','eligibility','enroll','apply to rvce','join rvce','get into rvce','admission process','how to get admission','ug adm','pg adm','ug b e'],id:'admissions',p:1.5},
    {k:['department','departments','branch','branches','stream','streams','course','courses','program','programmes','what courses','which branch','all branches','view programs'],id:'departments',p:2},
    {k:['ug','ug details'],id:'ug_disambiguation',p:2},
    {k:['ug programs','ug programmes','ug program','undergraduate','undergrad','b e','be','btech','b tech','ug courses','b e flavors','b e course','b e courses','be courses'],id:'ugPrograms',p:1.5},
    {k:['pg','pg program','pg programs','postgraduate','postgrad','m tech','mtech','masters','pg courses'],id:'pgPrograms',p:1.5},
    {k:['facility','facilities','infrastructure','what facilities','amenities','all facilities'],id:'facilities',p:2},
    {k:['website','site','official website','rvce website','visit website'],id:'website',p:2},
    // P3: Generic fallback
    {k:['about','rvce','college','history','founded','established','overview','tell me about','know about','information about'],id:'about',p:3},
    {k:['campus life','student life','extracurricular','clubs','life at rvce','campus','student experience','college life'],id:'campusLife',p:1.5},
    {k:['dress code','uniform','what to wear','clothes allowed','is there a uniform','can i wear shorts','can i wear jeans','dress rules'],id:'dress_code',p:0.8},
    {k:['anti ragging','ragging','helpline','report ragging','ragging completely banned','bullied','harassed','ragging helpline'],id:'anti_ragging',p:0.8},
    {k:['contact','phone','email','address','location','where is rvce','map','direction','call','bengaluru','bangalore'],id:'contact',p:3},
    {k:['menu','main menu','options','help','start','what can you do','show menu'],id:'menu',p:3},
];

// Human-readable labels for suggestion buttons
const INTENT_LABELS = {
    greet:'Say Hi 👋', bye:'Bye!', about:'About RVCE 🏫', hostels:'Hostels 🏠',
    transport:'How to Reach 🚌', wifi:'WiFi 📶', food:'Food & Canteen 🍛',
    exam:'Exams 📝', lateral:'Lateral Entry', nri:'NRI / International',
    scholarships:'Scholarships 🎓', jee:'JEE Info', examTypes:'KCET / COMED-K',
    fees:'Fee Structure 💰', management_quota:'Management Quota', cutoffs:'Cutoffs',
    innovationTeams:'Innovation Teams 💡',
    culturalLife:'Culture & Fests 🎭', vision:'Vision & Mission 🎯',
    principal:'Principal', ranking:'Rankings 🏆', accreditation:'Accreditation',
    timings:'Timings ⏰', trust:'Trust / RSST', research:'Research 🔬',
    mca:'MCA', phd:'PhD', vtu:'VTU', intake:'Seats / Intake',
    library:'Library 📚', sports:'Sports 🏅', autonomous:'Autonomous Status',
    placements:'Placements 💼', admissions:'Admissions 🎓',
    ugAdm:'UG (B.E.)', pgAdm:'PG (M.Tech)',
    departments:'Departments 📚', ugPrograms:'UG Programs', pgPrograms:'PG Programs',
    facilities:'Facilities 🏢', website:'Website 🌐', campusLife:'Campus Life 🏕️',
    contact:'Contact 📞', menu:'Main Menu 📋',
    dept_cs:'Computer Science & Engineering (CSE)', dept_aiml:'AI & Machine Learning (AIML)', dept_ec:'Electronics & Communication (ECE)',
    dept_me:'Mechanical Engineering (ME)', dept_cv:'Civil Engineering (CV)', dept_ee:'Electrical & Electronics (EEE)',
    dept_ae:'Aerospace Engineering (AE)', dept_bt:'Biotechnology (BT)', dept_ch:'Chemical Engineering (CH)',
    dept_is:'Information Science (ISE)', dept_csds:'Data Science (CSDS)', dept_cscy:'Cyber Security (CSCY)',
    dept_et:'Telecommunication (ETE)', dept_ei:'Instrumentation (EIE)', dept_im:'Industrial Engineering (IEM)',
    syllabus_1st_sem: '1st Year Syllabus 📚', dress_code: 'Dress Code 👔', anti_ragging: 'Anti-Ragging 🛑', hod_cs: 'CSE HOD 👨‍🏫'
};

function matchIntent(input) {
    const cleanInput = sanitize(input).toLowerCase();
    
    // 1. Universal Button-to-Intent Bypass
    for (const [id, label] of Object.entries(INTENT_LABELS)) {
        if (sanitize(label).toLowerCase() === cleanInput) return id;
    }
    for (const d of KB.departments.ug) {
        if (sanitize(d.n).toLowerCase() === cleanInput) return 'dept_' + d.c;
    }
    for (const d of KB.departments.pg) {
        if (sanitize(d.n).toLowerCase() === cleanInput) return 'dept_' + d.c;
    }
    const BUTTON_MAP = {
        'ug be': 'ugAdm', 'pg mtech': 'pgAdm', 'mca': 'mca', 'phd': 'phd',
        'view programs': 'ugPrograms', 'pg programs': 'pgPrograms', 'all departments': 'departments',
        'admissions page': 'admissions', 'apply': 'admissions',
        'placement details': 'placements', 'more info': 'admissions',
        'facilities': 'facilities', 'all facilities': 'facilities',
        'innovation teams': 'innovationTeams', 'see teams': 'innovationTeams',
        'cultural clubs': 'culturalLife', 'cultural teams': 'culturalLife',
        'sports info': 'sports', 'rvei website': 'trust',
        'website': 'website', 'email': 'contact', 'rvce edu in': 'website'
    };
    if (BUTTON_MAP[cleanInput]) return BUTTON_MAP[cleanInput];

    // 2. Exact match bypass: if the user types the exact keyword, automatically win.
    for (const q of QA) {
        if (q.k.includes(cleanInput)) return q.id;
    }

    let best = null, bestP = 99, bestL = 0;
    for (const q of QA) {
        for (const k of q.k) {
            // Match with RegExp for exact word boundaries
            // Escape special chars in k just in case
            const escapedK = k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regex = new RegExp('(?:^|\\s)' + escapedK + '(?=\\s|$)', 'i');
            
            if (regex.test(cleanInput)) {
                if (q.p < bestP || (q.p === bestP && k.length > bestL)) {
                    best = q.id; bestP = q.p; bestL = k.length;
                }
            }
        }
    }
    return best;
}

/* =============== FUZZY "DID YOU MEAN?" =============== */
function levenshtein(a, b) {
    const m = a.length, n = b.length;
    const dp = Array.from({length: m+1}, ()=> Array(n+1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++)
        for (let j = 1; j <= n; j++)
            dp[i][j] = Math.min(dp[i-1][j]+1, dp[i][j-1]+1, dp[i-1][j-1]+(a[i-1]!==b[j-1]?1:0));
    return dp[m][n];
}

function findSuggestions(input) {
    const words = sanitize(input).toLowerCase().split(/\s+/).filter(w => w.length > 2);
    const scored = new Map();
    for (const q of QA) {
        if (q.id === 'greet' || q.id === 'bye' || q.id === 'menu') continue;
        let minDist = Infinity;
        for (const k of q.k) {
            for (const w of words) {
                // Check each keyword and each word from input
                const kWords = k.split(/\s+/);
                for (const kw of kWords) {
                    if (kw.length < 3) continue;
                    const d = levenshtein(w, kw);
                    const threshold = Math.max(1, Math.floor(kw.length * 0.4));
                    if (d <= threshold && d < minDist) minDist = d;
                }
            }
        }
        if (minDist < Infinity) scored.set(q.id, minDist);
    }
    // Sort by distance, return top 3 unique
    const sorted = [...scored.entries()].sort((a,b) => a[1]-b[1]);
    const results = [];
    const seen = new Set();
    for (const [id] of sorted) {
        if (!seen.has(id) && results.length < 3) { results.push(id); seen.add(id); }
    }
    return results;
}

function getFollowUps(id) {
    const map = {
        ugPrograms: [{l:'Admissions info',a:'ugAdm',i:'🎓'},{l:'Campus Life',a:'campusLife',i:'🏕️'}],
        placements: [{l:'Top Companies',a:'about',i:'🏢'},{l:'Admissions',a:'admissions',i:'🎓'}],
        hostels: [{l:'Facilities',a:'facilities',i:'🏢'},{l:'Sports',a:'sports',i:'🏅'}],
        admissions: [{l:'Fee Structure',a:'fees',i:'💰'},{l:'Placements',a:'placements',i:'💼'}],
        dept_cs: [{l:'Placements',a:'placements',i:'💼'},{l:'HOD CSE',a:'hod_cs',i:'👨‍🏫'}]
    };
    return map[id] || [];
}

/* =============== TONE HELPER =============== */
function T(f, p) { return tone === 'funny' ? f : p; }

/* =============== RESPONSE GENERATOR =============== */
function getResponse(id) {
    const r = { text:'', buttons:[], noMenu:false };
    
    // Add conversational prefix for non-greeting/bye intents
    if (id !== 'greet' && id !== 'bye' && id !== 'menu') {
        r.text = getPrefix();
    }

    SESSION.lastIntent = id;

    switch(id) {
    case 'greet':
        r.text = T("Hey there! 👋 Welcome to RVCE — the place where engineers are crafted! 🔧 What would you like to know?","Hello! Welcome to RV College of Engineering. How can I assist you today?");
        r.noMenu = true; return r;
    case 'bye':
        r.text = T("See ya! 🙌 Hope I helped. Come back anytime!","Thank you for visiting. Feel free to return anytime. Have a good day!");
        r.buttons = [{l:'Visit Website',u:KB.contact.website,i:'🌐'}]; return r;
    case 'about':
        r.text += T("RVCE — engineering excellence since 1963! 🔧\n📍 16.85 acres on Mysuru Road, Bengaluru\n🏆 NAAC A+ | NIRF 101-150\n🎓 16 UG + 14 PG programs\n📄 100+ Patents | 20 Centres of Excellence",
            "RV College of Engineering, established in 1963, is situated on 16.85 acres on Mysuru Road, Bengaluru.\n\n• Accreditation: NAAC A+ Grade, NBA Accredited\n• Ranking: NIRF 101-150, #1 Private College (IIRF 2025)\n• Programs: 16 B.E., 14 M.Tech/MCA, PhD\n• Research: 100+ Patents, 20 Centres of Excellence");
        r.buttons = [{l:'Rankings',a:'ranking',i:'🏆'},{l:'Vision & Mission',a:'vision',i:'🎯'},{l:'Research',a:'research',i:'🔬'},{l:'Website',u:'https://rvce.edu.in/about_us/',i:'🌐'}]; break;
    case 'vision':
        r.text += T("RVCE's vision? Tech + Innovation + Sustainability = Future! 🚀","Vision: "+KB.general.vision); break;
    case 'principal':
        r.text += T("Dr. K.N. Subramanya is the Principal! With 34+ years experience, he leads the team! ⚓",
            "The Principal of RVCE is Dr. K.N. Subramanya.\n\nHe holds a B.E., M.Tech., MBA, and Ph.D., bringing over 34 years of experience in teaching, research, and administration.\n\nContact: principal@rvce.edu.in"); break;
    case 'ranking':
        r.text += T("RVCE is killing it! 🏆","RVCE Rankings:");
        r.text += "\n• "+KB.general.ranking+"\n• "+KB.general.accreditation; break;
    case 'accreditation':
        r.text += T("RVCE scored the top marks! 💎","Accreditation Details:");
        r.text += "\n• "+KB.general.accreditation+"\n• "+KB.general.status; break;
    case 'timings':
        r.text += T("⏰ "+KB.general.timings,"College timings: "+KB.general.timings); break;
    case 'trust':
        r.text += T("RVCE is powered by RSST! 🏛️","RVCE is managed by "+KB.general.trust+".");
        r.buttons = [{l:'RVEI Website',u:'https://rvei.edu.in/',i:'🌐'}]; break;
    case 'research':
        r.text += T("Research at RVCE is 🔥!","Research Highlights:");
        r.text += "\n• "+KB.general.research+"\n• Domains: "+KB.general.researchDomains; break;
    case 'admissions':
        r.text += T("Let's get you enrolled! 🎓","Admission Information:");
        r.buttons = [{l:'UG (B.E.)',a:'ugAdm',i:'🎓'},{l:'PG (M.Tech)',a:'pgAdm',i:'📘'},{l:'MCA',a:'mca',i:'💻'},{l:'PhD',a:'phd',i:'🧪'},{l:'Admissions Page',u:KB.admissions.url,i:'🌐'}]; break;
    case 'ugAdm':
        r.text += T("B.E. admission details 📋:","UG Admission:");
        r.text += "\n• Eligibility: "+KB.admissions.ug.eligibility+"\n• Exams: "+KB.admissions.ug.exams+"\n• "+KB.admissions.ug.quotas;
        r.buttons = [{l:'View Programs',a:'ugPrograms',i:'📋'},{l:'Apply',u:KB.admissions.url,i:'🌐'}]; break;
    case 'pgAdm':
        r.text += T("M.Tech time! 🚀","PG Admission:");
        r.text += "\n• Eligibility: "+KB.admissions.pg.eligibility+"\n• Exams: "+KB.admissions.pg.exams;
        r.buttons = [{l:'PG Programs',a:'pgPrograms',i:'📋'},{l:'Apply',u:KB.admissions.url,i:'🌐'}]; break;
    case 'jee':
        r.text += T("⚠️ JEE Mains is NOT accepted at RVCE! You need KCET, COMED-K, or Management Quota.","Important: JEE Mains scores are NOT considered for RVCE admission. Accepted exams: KCET (KEA), COMED-K, and Management Quota.");
        r.buttons = [{l:'Admission Info',a:'admissions',i:'🎓'}]; break;
    case 'examTypes':
        r.text += T("Ways to get in 🎯:","Admission Modes:");
        r.text += "\n• KCET (KEA) — Karnataka entrance\n• COMED-K — Private colleges\n• Management Quota\n• Special: CIWG/PIO/OCI/Nepal";
        r.buttons = [{l:'More Info',u:KB.admissions.url,i:'🌐'}]; break;
    case 'management_quota':
        r.text += T("Management Quota Seats 💰:","Management Quota Information:");
        r.text += "\n• Admission is based on academic performance and seat availability.\n• Fees: "+KB.admissions.fees;
        r.buttons = [{l:'Contact Admissions',a:'contact',i:'📞'},{l:'Admissions Page',u:KB.admissions.url,i:'🌐'}]; break;
    case 'cutoffs':
        r.text += T("Rankings & Cutoffs 📊:","KCET/COMEDK Cutoffs:");
        r.text += "\n• "+KB.admissions.cutoffs+"\n• Note: Cutoffs vary significantly by year and category.";
        r.buttons = [{l:'KEA Website',u:'https://cetonline.karnataka.gov.in/kea/',i:'🌐'},{l:'Admissions Info',a:'admissions',i:'🎓'}]; break;
    case 'scholarships':
        r.text += T("Scholarships & Aid 🎓:","Financial Support:");
        r.text += "\n• "+KB.placements.scholarships;
        r.buttons = [{l:'More Details',u:'https://rvce.edu.in/scholarships/',i:'🌐'}]; break;
    case 'lateral':
        r.text += T("Lateral Entry (Diploma) 🔄:","Admission for Diploma Holders:");
        r.text += "\n• Direct admission to 2nd year B.E.\n• Mandatory Requirement: DCET (Diploma CET) rank.";
        r.buttons = [{l:'Admissions Page',u:KB.admissions.url,i:'🌐'}]; break;
    case 'fees':
        r.text += T("Tuition fees depend on the admission quota:<br>• <strong>KCET:</strong> ~₹1,00,000 to ₹1,20,000 per year<br>• <strong>COMEDK:</strong> ~₹2,50,000 to ₹3,00,000 per year<br>• <strong>Management:</strong> Can exceed ₹10L depending on branch.<br><em>Note: Hostels cost an additional ₹1.1L - ₹1.3L per year.</em>",
            "Tuition fees depend on the admission quota:<br>• <strong>KCET:</strong> ~₹1,00,000 to ₹1,20,000 per year<br>• <strong>COMEDK:</strong> ~₹2,50,000 to ₹3,00,000 per year<br>• <strong>Management:</strong> ~₹16L to ₹70L total over 4 years.");
        r.buttons = [{l:'Admissions Info',a:'admissions',i:'🎓'}]; break;
    case 'placements':
        r.text += T("Our record is legendary! 🚀","Placement Statistics:");
        r.text += "\n• Max: " + KB.placements.maxSalary + "\n• Avg: " + KB.placements.avgSalary + "\n• " + KB.placements.offers + "\n• " + KB.placements.companies;
        r.buttons = [{l:'Placement Training',u:KB.placements.url,i:'🌐'}]; break;
    case 'refund_policy':
        r.text += T("Refund policy follows AICTE rules! 💸<br><br>• Before start: Full refund (-₹1k)<br>• After start: Only if seat filled<br>• Document retention is BANNED.",
            "The Fee Refund Policy strictly follows <strong>AICTE Regulations</strong>.<br><br>• <strong>Before Course Start:</strong> Full refund minus a processing fee (max ₹1,00,0).<br>• <strong>After Course Start:</strong> Refundable only if the vacated seat is filled.<br>• <strong>Original Docs:</strong> By AICTE mandate, colleges cannot retain original certificates.");
        break;
    case 'syllabus_1st_sem':
        r.text += T("1st Year Syllabus (VTU 2022 Scheme) 📚<br><br>Physics & Chemistry cycles apply! Key subjects include Math, Electronics, C-Programming.",
            "The <strong>1st Year B.E. Syllabus</strong> follows the VTU 2022 Scheme.<br><br>Students are divided into Physics and Chemistry Cycles. Key subjects include:<br>• Engineering Mathematics<br>• Basic Electronics/Electrical<br>• Programming in C");
        r.buttons = [{l:'Download Syllabus PDF',u:'https://rvce.edu.in/sites/default/files/FIRST-YEAR-SYLLABUS-BOOK-2022-SCHEMEFORPRINT.pdf',i:'📑'}]; break;
    case 'hod_cs':
        r.text += T("Dr. Shanta Rangaswamy is the Head of CSE! 👨‍🏫", "The Head of Department for <strong>Computer Science & Engineering (CSE)</strong> is <strong>Dr. Shanta Rangaswamy</strong>.");
        r.buttons = [{l:'CSE Faculty Page',u:dUrl('cs'),i:'🌐'}]; break;
    case 'dress_code':
        r.text += T("Dress sharp! 👔 No shorts or ripped jeans. Casuals are okay, but labs require safety gear (Khakis/Aprons)!",
            "As an institution affiliated with <strong>VTU</strong>, RVCE enforces a dress code that aligns with professional and academic decorum.<br><br>• <strong>General Wear:</strong> Clean, neat, and non-revealing casual wear is permitted.<br>• <strong>Prohibited:</strong> Shorts, ripped jeans, revealing tops.<br>• <strong>Labs/Workshops:</strong> Closed-toe shoes and safety uniforms mandatory.");
        break;
    case 'anti_ragging':
        r.text += T("Ragging is a crime! 🛑 Total ban at RVCE.<br><br>🚨 National Helpline: 1800-180-5522",
            "RVCE strictly adheres to the <strong>UGC Regulations on Curbing the Menace of Ragging (2009)</strong>. Ragging is a criminal offense.<br><br>🚨 <strong>National 24x7 Anti-Ragging Helpline:</strong> 1800-180-5522<br>Email: helpline@antiragging.in");
        r.buttons = [{l:'Anti-Ragging Portal',u:'https://www.antiragging.in/',i:'🛑'}]; break;
    case 'innovationTeams':
        r.text += T("RVCE = Innovation! 💡 Join a team:","Innovative Student Teams:");
        r.text += "\n• " + KB.campus.teams.join("\n• ");
        r.buttons = [{l:'See Innovation',u:KB.campus.urls.innovation,i:'🌐'}]; break;
    case 'culturalLife':
        r.text += T("Student life is more than classes! 🎭","Cultural Activities & Clubs:");
        r.text += "\n• Clubs: " + KB.campus.clubs.join(", ") + "\n• Fest: " + KB.campus.fest;
        r.buttons = [{l:'Cultural Teams',u:KB.campus.urls.cultural,i:'🌐'}]; break;
    case 'contact':
        r.text += T("Here's how to reach RVCE! 📞","Contact Information:");
        r.text += "\n📍 "+KB.contact.address+"\n📱 "+KB.contact.phone+"\n📧 "+KB.contact.email+"\n🎓 Admissions: "+KB.contact.admissionPhone;
        r.buttons = [{l:'Website',u:KB.contact.website,i:'🌐'},{l:'Email',u:'mailto:'+KB.contact.email,i:'📧'}]; break;
    case 'website':
        r.text += T("Here you go! 🌐","Official Website:");
        r.buttons = [{l:'rvce.edu.in',u:KB.contact.website,i:'🌐'}]; break;
    case 'intake':
        r.text += T("RVCE admits 2000+ students every year! 🎓","Annual intake: "+KB.general.intake+"."); break;
    case 'ug_disambiguation':
        r.text += T("Academic explorer! 🗺️ Are you looking to see the **Programmes List** or do you need **Admission Details** for UG?","Would you like to explore Undergraduate (B.E.) Programmes or check Admission Details?");
        r.buttons = [
            {l:'Programmes List 📜',a:'ugPrograms',i:'📋'},
            {l:'Admission Process 🎓',a:'ugAdm',i:'🎫'}
        ]; 
        return r;
    case 'ugPrograms':
        r.text += T("RVCE offers 16 Undergraduate (B.E.) programs including:\n• Computer Science & Engg (CSE)\n• Electronics & Communication (ECE)\n• Information Science & Engg (ISE)\n• Mechanical Engineering (ME)\n• Civil Engineering (CV)\n• Biotechnology (BT)\n• AI & Machine Learning (AIML)","RVCE offers 16 B.E. programs including CSE, ECE, ISE, ME, CV, BT, and AIML. See the full list below:");
        r.buttons = [
            {l:'View All on Website',u:'https://rvce.edu.in/programmes/',i:'🌐'},
            {l:'Admission Info',a:'ugAdm',i:'🎓'}
        ]; break;
    case 'pgPrograms':
        r.text += T("RVCE offers 14 Postgraduate programs:\n• M.Tech (CSE, VLSI, Power Electronics, etc.)\n• Master of Computer Applications (MCA)\n• Ph.D. Research Programs","RVCE offers 14 PG programs including M.Tech in various specializations, MCA, and Ph.D. research options.");
        r.buttons = [{l:'PG Programs Page',u:'https://rvce.edu.in/programmes/',i:'🌐'},{l:'MCA Details',a:'mca',i:'💻'}]; break;
    case 'mca':
        r.text += T("Master of Computer Applications (MCA) 💻:","MCA Details:");
        r.text += "\n• Duration: 2 Years\n• " + KB.admissions.mca.eligibility;
        r.buttons = [{l:'MCA Dept Page',u:dUrl('mca'),i:'🌐'}]; break;
    case 'phd':
        r.text += T("Doctoral Programs (Ph.D.) 🧪:","Research Programs:");
        r.text += "\n• " + KB.admissions.phd.info;
        r.buttons = [{l:'Research Centres',a:'research',i:'🔬'}]; break;
    case 'departments':
        r.text += T("Explore our departments! 📚 Choose a cycle to see details or visit the main catalog:","Academic Departments:");
        r.buttons = [{l:'UG (B.E.) List',a:'ugPrograms',i:'📋'},{l:'PG Programs List',a:'pgPrograms',i:'📘'},{l:'Official Website',u:'https://rvce.edu.in/programmes/',i:'🌐'}]; break;
    case 'campusLife':
        r.text += T("Life at RVCE is vibrant! 🏕️","Student Experience & Campus Life:");
        r.text += "\n• Cultural Clubs\n• Technical Innovation Teams\n• Annual Fest: " + KB.campus.fest;
        r.buttons = [{l:'Cultural Clubs',a:'culturalLife',i:'🎭'},{l:'Innovation Teams',a:'innovationTeams',i:'💡'}]; break;
    case 'hostels':
        r.text += T("Home away from home 🏠:","Hostel Facilities:");
        r.text += "\n• Boys: " + KB.hostels.boys + "\n• Girls: " + KB.hostels.girls + "\n• Amenities: " + KB.hostels.amenities;
        r.buttons = [{l:'See Facilities',u:KB.hostels.url,i:'🌐'}]; break;
    case 'stats_disambiguation':
        r.text += T("Check out the numbers! 📊","RVCE Statistics:");
        r.buttons = [{l:'Placement Stats',a:'placements',i:'💼'},{l:'NIRF & Rankings',a:'ranking',i:'🏆'},{l:'Research Stats',a:'research',i:'🔬'}]; break;
    case 'facilities':
        r.text += T("Top-notch facilities 🏢:","Campus Infrastructure:");
        r.text += "\n• " + KB.facilities.list.join("\n• ");
        r.buttons = [{l:'Full Details',u:KB.facilities.url,i:'🌐'}]; break;
    case 'vtu':
        r.text += T("VTU affiliated but autonomous for UG! 🏛️","RVCE is affiliated to VTU (Visvesvaraya Technological University) and has Autonomous status for UG programs."); break;
    case 'transport':
        r.text += T("Getting to RVCE 🚌:\n• Located on Mysuru Road, ~13 km from city center\n• BMTC buses: Multiple routes to RVCE stop\n• Nearest Metro: Kengeri station\n• Autos & cabs: Easily available\n• Near NICE Road junction",
            "How to Reach RVCE:\n• Location: Mysuru Road, ~13 km from Bengaluru city center\n• Bus: BMTC bus routes serve the RVCE stop directly\n• Metro: Kengeri Metro station is the nearest\n• Auto/Cab: Easily accessible via Mysuru Road\n• Near NICE Road junction"); break;
    case 'wifi':
        r.text += T("Yes! Wi-Fi everywhere! 📶 Campus + Hostels!","Wi-Fi is available across the campus and in hostel blocks."); break;
    case 'food':
        r.text += T("Hungry? 🍛 RVCE has a food court + veg mess in hostels. Plenty of options around too!","RVCE has a food court on campus and vegetarian mess in hostels. Multiple eateries are also available nearby."); break;
    case 'exam':
        r.text += T("Exams? 📝 Semester system with CIE + SEE. Being autonomous, RVCE sets its own papers!","RVCE follows a semester system with Continuous Internal Evaluation (CIE) and Semester End Examination (SEE). As an autonomous institution, it designs its own syllabus and sets examination papers."); break;
    case 'lateral':
        r.text += T("Diploma holders can join 2nd year via DCET! 🔄","Lateral entry to 2nd year B.E. is available for diploma holders through DCET (Diploma CET).");
        r.buttons = [{l:'Admissions',u:KB.admissions.url,i:'🌐'}]; break;
    case 'nri':
        r.text += T("International students welcome! 🌍 CIWG/PIO/OCI/Nepal quotas available!","International admissions: Quotas available for CIWG, PIO, OCI, and Nepal Citizens.");
        r.buttons = [{l:'Admissions',u:KB.admissions.url,i:'🌐'}]; break;
    case 'library':
        r.text += T("The Central Library is a knowledge fortress! 📚","Central Library:");
        r.text += "\n• 100,000+ books, journals, and e-resources\n• Digital library with IEEE, Springer, Elsevier access\n• Reading rooms and group study areas\n• Open during college hours";
        r.buttons = [{l:'Facilities',u:KB.facilities.url,i:'🌐'}]; break;
    case 'sports':
        r.text += T("Sporty campus! 🏅","Sports Facilities:");
        r.text += "\n• 400m athletic track\n• Cricket & Football grounds\n• Basketball, Volleyball, Badminton courts\n• Gymnatorium with modern equipment\n• Table Tennis, Chess";
        r.buttons = [{l:'Sports Info',u:'https://rvce.edu.in/facilities/sports_and_gymnatorium/',i:'🌐'}]; break;
    case 'autonomous':
        r.text += T("RVCE is autonomous for UG — they design their own syllabus and exams! 📋 For PG, it's affiliated to VTU.","RVCE has Autonomous status for UG programs, meaning it designs its own curriculum and conducts its own examinations. PG programs are affiliated to VTU."); break;
    case 'menu':
        r.text = T("How can I help? Choose a topic:","Main Menu — Choose a topic:");
        r.noMenu = true; return r;
    default:
        // Handle department links
        if (id && id.startsWith('dept_')) {
            const c = id.replace('dept_','');
            const d = KB.departments.ug.find(x=>x.c===c);
            if (d) { 
                r.text += T(d.n+" — great choice! 🎯","Department: "+d.n);
                r.buttons = [{l:'Department Page',u:dUrl(c),i:'🌐'},{l:'All Departments',a:'departments',i:'📚'}];
                return r; 
            }
        }
        r.text = T("Hmm 🤔 I didn't get that. Try one of these:","I didn't understand that query. Here are some options:");
        r.noMenu = true; return r;
    }

    // Append dynamic follow-up suggestions
    const followUps = getFollowUps(id);
    if (!r.noMenu) {
        r.buttons = [...(r.buttons || []), ...followUps];
    }

    return r;
}

/* =============== DOM =============== */
const $=s=>document.getElementById(s);
const chatW=$('chatWindow'),fab=$('chatFab'),badge=$('fabBadge'),msgs=$('chatMessages');
const typing=$('typingIndicator'),inp=$('userInput'),sendB=$('sendBtn');
const toneS=$('toneSwitch'),toneL=$('toneLabel'),emojiB=$('emojiBtn'),micB=$('micBtn'),sugs=$('quickSuggestions');

fab.addEventListener('click',()=>{chatOpen=!chatOpen;chatW.classList.toggle('open',chatOpen);fab.classList.toggle('active',chatOpen);if(chatOpen){badge.classList.add('hidden');inp.focus();}});
toneS.addEventListener('click',()=>{tone=tone==='funny'?'pro':'funny';toneS.classList.toggle('pro',tone==='pro');toneL.textContent=tone==='funny'?'Funny':'Pro';});
emojiB.addEventListener('click',()=>{disOld();showMenu();});
sugs.querySelectorAll('.suggestion-chip').forEach(c=>c.addEventListener('click',()=>process(c.dataset.query)));
sendB.addEventListener('click',()=>{const t=inp.value.trim();if(t)process(t);});
inp.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();const t=inp.value.trim();if(t)process(t);}});

/* =============== VOICE RECOGNITION =============== */
let recognition;
let isRecording = false;

if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
        isRecording = true;
        micB.classList.add('recording');
        inp.placeholder = "Listening... 🎤";
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        inp.value = transcript;
        setTimeout(() => process(transcript), 500);
    };

    recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        stopRecording();
    };

    recognition.onend = () => {
        stopRecording();
    };
}

function stopRecording() {
    isRecording = false;
    if(recognition) recognition.stop();
    micB.classList.remove('recording');
    inp.placeholder = "Ask me anything about RVCE...";
}

micB.addEventListener('click', () => {
    if (!recognition) {
        alert("Speech Recognition not supported in this browser. Try Chrome!");
        return;
    }
    if (isRecording) {
        stopRecording();
    } else {
        recognition.start();
    }
});

function process(text) {
    // MODERATION CHECK — runs BEFORE intent matching (use original text)
    const mod = checkModeration(text);
    if (mod.blocked) {
        addUser(text);
        inp.value = '';
        disOld();
        showTyp();
        setTimeout(()=>{hideTyp();addBotWarn(getModerationResponse(mod.type));},600);
        return;
    }

    // Intent matching uses sanitized input (special chars stripped)
    const id = matchIntent(text);
    
    // Visually correct the user's input to the formal label if it matches an intent
    let displayText = text;
    if (id && INTENT_LABELS[id]) {
        displayText = INTENT_LABELS[id];
    } else if (id && id === 'stats_disambiguation') {
        displayText = "Placement Stats";
    }

    addUser(displayText);
    inp.value = '';
    disOld();

    if (id === 'greet') { botReply(getResponse('greet')); setTimeout(showMenu,1200); }
    else if (id === 'menu') { setTimeout(showMenu,300); }
    else if (id) { botReply(getResponse(id)); }
    else {
        // No match — try fuzzy suggestions
        const suggestions = findSuggestions(text);
        if (suggestions.length > 0) {
            const r = { text: '', buttons: [], noMenu: false };
            r.text = T(
                "Hmm 🤔 I didn't quite get that! Did you mean this:",
                "I couldn't find an exact match. Did you mean this:"
            );
            r.buttons = suggestions.map(sid => ({
                l: INTENT_LABELS[sid] || sid,
                a: sid,
                i: '🔍'
            }));
            botReply(r);
        } else {
            const r = { text: '', buttons: [], noMenu: false };
            r.text = T(
                "Sorry, I couldn't find anything for that! 😅 Try something from the menu:",
                "I'm sorry, I don't have information on that topic. Please choose from the menu below:"
            );
            r.noMenu = true;
            botReply(r);
            setTimeout(showMenu, 600);
        }
    }
}

/* =============== MESSAGE RENDERING =============== */
function addUser(text) {
    const m=document.createElement('div'); m.className='message user';
    m.innerHTML=`<div class="msg-av"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><div class="msg-body"><div class="msg-bubble">${esc(text)}</div></div>`;
    msgs.appendChild(m); scr();
}

function addBot(text, buttons, noMenu) {
    const m=document.createElement('div'); m.className='message bot';
    let bh='';
    if(buttons && buttons.length){
        bh='<div class="msg-btns">';
        buttons.forEach(b=>{
            if(b.u) bh+=`<button class="act-btn lk" onclick="window.open('${b.u}','_blank')">${b.i||'🔗'} ${b.l}</button>`;
            else bh+=`<button class="act-btn" data-action="${b.a}">${b.i||''} ${b.l}</button>`;
        });
        // Only add universal menu if not explicitly suppressed AND not already in button list
        const hasMenu = buttons.some(b => b.a === 'menu');
        if(!noMenu && !hasMenu) {
            bh+=`<button class="act-btn mn" data-action="menu">📋 Main Menu</button>`;
        }
        bh+='</div>';
    } else if(!noMenu) {
        bh='<div class="msg-btns"><button class="act-btn mn" data-action="menu">📋 Main Menu</button></div>';
    }
    
    // Simple markdown: **bold** and \n to <br>
    let fmt = (text||'').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    fmt = fmt.replace(/\n/g,'<br>');
    
    m.innerHTML=`<div class="msg-av"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg></div><div class="msg-body"><div class="msg-bubble">${fmt}</div>${bh}</div>`;
    msgs.appendChild(m);
    m.querySelectorAll('.act-btn[data-action]').forEach(b=>b.addEventListener('click',()=>{disOld();handleAction(b.dataset.action);}));
    scr();
}

function addBotWarn(text) {
    const m=document.createElement('div'); m.className='message bot';
    m.innerHTML=`<div class="msg-av"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg></div><div class="msg-body"><div class="msg-bubble warn">${text.replace(/\n/g,'<br>')}</div><div class="msg-btns"><button class="act-btn mn" data-action="menu">📋 Main Menu</button></div></div>`;
    msgs.appendChild(m);
    m.querySelectorAll('.act-btn[data-action]').forEach(b=>b.addEventListener('click',()=>{disOld();handleAction(b.dataset.action);}));
    scr();
}

function botReply(r) {
    if(!r)return;showTyp();
    const d=400+Math.min((r.text||'').length*4,700);
    setTimeout(()=>{hideTyp();addBot(r.text,r.buttons,r.noMenu);},d);
}

function showMenu() {
    const btns=[
        {l:'About RVCE',a:'about',i:'🏫'},{l:'Admissions',a:'admissions',i:'🎓'},
        {l:'Departments',a:'departments',i:'📚'},{l:'Placements',a:'placements',i:'💼'},
        {l:'Campus Life',a:'campusLife',i:'🏕️'},{l:'Hostels',a:'hostels',i:'🏠'},
        {l:'Contact',a:'contact',i:'📞'},{l:'Website',u:KB.contact.website,i:'🌐'}
    ];
    showTyp();
    setTimeout(()=>{hideTyp();addBot(T("Pick your adventure! 🗺️","How can I help? Choose a topic:"),btns,true);},400);
}

function handleAction(a) { if(a==='menu'){showMenu();return;} const r=getResponse(a); if(!r){showMenu();return;} botReply(r); }
function disOld() { msgs.querySelectorAll('.act-btn:not([disabled])').forEach(b=>b.disabled=true); }
function showTyp() { typing.classList.add('show'); scr(); }
function hideTyp() { typing.classList.remove('show'); }
function scr() { requestAnimationFrame(()=>{msgs.scrollTop=msgs.scrollHeight;}); }
function esc(t) { const d=document.createElement('div');d.textContent=t;return d.innerHTML; }

/* =============== PARTICLES =============== */
const cvs=$('particles'),ctx=cvs.getContext('2d');let pts=[];
function rz(){cvs.width=innerWidth;cvs.height=innerHeight;}
addEventListener('resize',rz);rz();
for(let i=0;i<50;i++)pts.push({x:Math.random()*cvs.width,y:Math.random()*cvs.height,vx:(Math.random()-0.5)*0.3,vy:(Math.random()-0.5)*0.3,r:Math.random()*2+0.5,a:Math.random()*0.3+0.1});
function draw(){
    ctx.clearRect(0,0,cvs.width,cvs.height);
    pts.forEach(p=>{p.x+=p.vx;p.y+=p.vy;if(p.x<0)p.x=cvs.width;if(p.x>cvs.width)p.x=0;if(p.y<0)p.y=cvs.height;if(p.y>cvs.height)p.y=0;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle=`rgba(124,58,237,${p.a})`;ctx.fill();});
    for(let i=0;i<pts.length;i++)for(let j=i+1;j<pts.length;j++){const dx=pts[i].x-pts[j].x,dy=pts[i].y-pts[j].y,d=Math.sqrt(dx*dx+dy*dy);if(d<120){ctx.beginPath();ctx.moveTo(pts[i].x,pts[i].y);ctx.lineTo(pts[j].x,pts[j].y);ctx.strokeStyle=`rgba(124,58,237,${0.06*(1-d/120)})`;ctx.lineWidth=0.5;ctx.stroke();}}
    requestAnimationFrame(draw);
}
draw();

/* =============== INIT =============== */
setTimeout(()=>{
    chatOpen=true;chatW.classList.add('open');fab.classList.add('active');badge.classList.add('hidden');
    setTimeout(()=>{addBot(T("Hey there! 👋 Welcome to RVCE — the place where engineers are crafted! Ask me anything about admissions, placements, campus, and more!","Hello! Welcome to RV College of Engineering. I'm here to help you with information about admissions, placements, campus facilities, and more."),[],true);setTimeout(showMenu,900);},350);
},600);

})();
